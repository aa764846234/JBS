package model;

public class text {
	private String txt;

	public String getTxt() {
		return txt;
	}

	public void setTxt(String txt) {
		this.txt = txt;
	}

	public text(String txt) {
		super();
		this.txt = txt;
	}
	
}
