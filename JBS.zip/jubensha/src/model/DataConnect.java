package model;

import java.sql.*;

public class DataConnect {
	private static Statement stat;
	private static void init() throws ClassNotFoundException, SQLException{
		Class.forName("com.mysql.jdbc.Driver");
		String url="jdbc:mysql://localhost:3306/jbs";
		String user="root";
		String password="123456";
		Connection con = DriverManager.getConnection(url,user,password);
		stat = con.createStatement();
	}
	public static Statement getStat() throws ClassNotFoundException, SQLException{
		if(stat == null)
			init();
		return stat;
	}
}
