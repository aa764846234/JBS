package model;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


public class admin implements Serializable {
	private String aid;
	private String apw;

	public admin(String aid, String apw) {
		super();
		this.aid = aid;
		this.apw = apw;
	}

	public String getAid() {
		return aid;
	}

	public void setAid(String aid) {
		this.aid = aid;
	}

	public String getApw() {
		return apw;
	}

	public void setApw(String apw) {
		this.apw = apw;
	}

	/**
	 * ��¼
	 * 
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * 
	 */
	public static admin Aloging(String id, String pw) throws SQLException,
			ClassNotFoundException {
		admin a = null;
		String sql = "select * from admin_login where aid='"+id+"' and apw = '"+pw+"'";
		ResultSet rs = DataConnect.getStat().executeQuery(sql);
		if(rs.next()){
			a = new admin(id,pw);
		}
		return a;

	}

	/**
	 * �鿴�籾
	 * 
	 */


	/**
	 * ���Ӿ籾
	 * 
	 */

	/**
	 * ɾ���籾
	 * 
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * 
	 */
	public void Adeletscript(String scriptname) throws SQLException,
			ClassNotFoundException {
		String sql = "delete from script1 where scriptname =" + scriptname;
		DataConnect.getStat().executeUpdate(sql);

	}

	/**
	 * ɾ������籾
	 * 
	 * @return
	 * 
	 */


	/**
	 * �鿴�û�
	 * 
	 */
	public ArrayList<user> searchUser(String username) throws SQLException, ClassNotFoundException {
		ArrayList<user> users= new ArrayList<user>();
		String sql = "select * from login where username like '%"+username+"%'";
		ResultSet rs = DataConnect.getStat().executeQuery(sql);
		while(rs.next()){
			users.add(new user(rs.getString("uid"),rs.getString(2),rs.getString(3)));
		}
		return users;
	}

	/**
	 * ɾ���û�
	 * 
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * 
	 */
	public void Adeletuser(String username) throws SQLException,
			ClassNotFoundException {
		String sql = "delete from login where username =" + username;
		DataConnect.getStat().executeUpdate(sql);

	}

	/**
	 * �޸��û�����
	 * @throws ClassNotFoundException 
	 * @throws SQLException 
	 * 
	 */
	public void Aalteuser(user u) throws SQLException, ClassNotFoundException {
		String sql = "update login set username='" + u.getUid()
				+ "' , password = '" + u.getUpw() + "'";
		System.out.println(sql);
		DataConnect.getStat().executeUpdate(sql);
	}
}
