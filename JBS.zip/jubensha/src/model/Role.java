package model;

public class Role{
	private String userid;
	private int roomid;
	private String rolename;
	private String rquqing;

	public String getRolename() {
		return rolename;
	}

	public void setRolename(String rolename) {
		this.rolename = rolename;
	}

	public String getRquqing() {
		return rquqing;
	}

	public void setRquqing(String rquqing) {
		this.rquqing = rquqing;
	}


	public int getRoomid() {
		return roomid;
	}

	public void setRoomid(int roomid) {
		this.roomid = roomid;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public Role(String userid, int roomid, String rolename, String rquqing) {
		super();
		this.userid = userid;
		this.roomid = roomid;
		this.rolename = rolename;
		this.rquqing = rquqing;
	}




}