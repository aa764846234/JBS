package model;

public class visitscript {
	private int scriptid;
	private int juqingid;
	private int clueid;
	private String introduce;
	private String role1;
	private String role2;
	private String role3;
	private String role4;
	private String role1story;
	private String role2story;
	private String role3story;
	private String role4story;
	private String clue;


	public visitscript(int scriptid, int juqingid, int clueid,
			String introduce, String role1, String role2, String role3,
			String role4, String role1story, String role2story,
			String role3story, String role4story, String clue) {
		super();
		this.scriptid = scriptid;
		this.juqingid = juqingid;
		this.clueid = clueid;
		this.introduce = introduce;
		this.role1 = role1;
		this.role2 = role2;
		this.role3 = role3;
		this.role4 = role4;
		this.role1story = role1story;
		this.role2story = role2story;
		this.role3story = role3story;
		this.role4story = role4story;
		this.clue = clue;
	}

	public int getScriptid() {
		return scriptid;
	}

	public String getRole2story() {
		return role2story;
	}

	public void setRole2story(String role2story) {
		this.role2story = role2story;
	}

	public String getRole3story() {
		return role3story;
	}

	public void setRole3story(String role3story) {
		this.role3story = role3story;
	}

	public String getRole4story() {
		return role4story;
	}

	public void setRole4story(String role4story) {
		this.role4story = role4story;
	}

	public void setScriptid(int scriptid) {
		this.scriptid = scriptid;
	}

	public int getJuqingid() {
		return juqingid;
	}

	public void setJuqingid(int juqingid) {
		this.juqingid = juqingid;
	}

	public int getClueid() {
		return clueid;
	}

	public void setClueid(int clueid) {
		this.clueid = clueid;
	}

	public String getIntroduce() {
		return introduce;
	}

	public void setIntroduce(String introduce) {
		this.introduce = introduce;
	}

	public String getRole1() {
		return role1;
	}

	public void setRole1(String role1) {
		this.role1 = role1;
	}

	public String getRole2() {
		return role2;
	}

	public void setRole2(String role2) {
		this.role2 = role2;
	}

	public String getRole3() {
		return role3;
	}

	public void setRole3(String role3) {
		this.role3 = role3;
	}

	public String getRole4() {
		return role4;
	}

	public void setRole4(String role4) {
		this.role4 = role4;
	}

	public String getRole1story() {
		return role1story;
	}

	public void setRole1story(String role1story) {
		this.role1story = role1story;
	}

	public String getClue() {
		return clue;
	}

	public void setClue(String clue) {
		this.clue = clue;
	}

}
