package model;

public class writetext {
	private String txt;

	public String getTxt() {
		return txt;
	}

	public void setTxt(String txt) {
		this.txt = txt;
	}

	public writetext(String txt) {
		super();
		this.txt = txt;
	}

}
