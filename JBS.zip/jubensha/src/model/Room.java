package model;

public class Room {
	private int rid;
	private int scriptid;
	private String script;
	private int number;
	private String role1;
	private String role2;
	private String role3;
	private String role4;

	public Room(int rid, int scriptid, String script, int number, String role1,
			String role2, String role3, String role4) {
		super();
		this.rid = rid;
		this.scriptid = scriptid;
		this.script = script;
		this.number = number;
		this.role1 = role1;
		this.role2 = role2;
		this.role3 = role3;
		this.role4 = role4;
	}

	public int getRid() {
		return rid;
	}

	public void setRid(int rid) {
		this.rid = rid;
	}

	public int getScriptid() {
		return scriptid;
	}

	public void setScriptid(int scriptid) {
		this.scriptid = scriptid;
	}

	public String getScript() {
		return script;
	}

	public void setScript(String script) {
		this.script = script;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public String getRole1() {
		return role1;
	}

	public void setRole1(String role1) {
		this.role1 = role1;
	}

	public String getRole2() {
		return role2;
	}

	public void setRole2(String role2) {
		this.role2 = role2;
	}

	public String getRole3() {
		return role3;
	}

	public void setRole3(String role3) {
		this.role3 = role3;
	}

	public String getRole4() {
		return role4;
	}

	public void setRole4(String role4) {
		this.role4 = role4;
	}

	public void joinroom() {
		String roomid1 = null;
		String sql = "select roomid from room";
		while (true) {
			if (roomid1 == sql) {
				System.out.print("����ɹ�");
				break;

			} else {
				System.out.print("");
			}
		}

	}

}
