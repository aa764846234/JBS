package model;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;

public class user implements Serializable {
	private String uid;
	private String username;
	private String upw;
	int roomid;

	public void setRoomid(int roomid) {
		this.roomid = roomid;
	}

	public user(int roomid) {
		super();
		this.roomid = roomid;
	}

	public String getUid() {
		return uid;
	}
	public int getRoomid(){
		return roomid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUpw() {
		return upw;
	}

	public void setUpw(String upw) {
		this.upw = upw;
	}

	public user(String uid, String username, String upw) {
		super();
		this.uid = uid;
		this.username = username;
		this.upw = upw;
	}
	public static user aloging(String uid,String password) throws SQLException, ClassNotFoundException{
		user a = null;
		String sql = "select * from login where uid='" + uid + "' and password = '"+ password + "'";
		ResultSet rs = DataConnect.getStat().executeQuery(sql);
		if (rs.next()) {
			a = new user(uid,rs.getString("username"),password);
		}
		return a;
     }

	public static void register(user u) throws SQLException, ClassNotFoundException {
		String sql ="insert into login (uid,password) values ('"+
		u.getUid()+"','"+u.getUpw()+"')";
		DataConnect.getStat().executeUpdate(sql);
	}

	public void chooserole(Role r) throws SQLException, ClassNotFoundException {
		String sql ="insert into record (username,roomid,role,story) values ('"+r.getUserid()+"','"+r.getRoomid()+"','"+
		r.getRolename()+"','"+r.getRquqing()+"')";
		DataConnect.getStat().executeUpdate(sql);
	}




	public static void creatroom(Room sr) throws SQLException, ClassNotFoundException{
		String sql ="insert into room (scriptid,scriptname,number,role1,role2,role3,role4) values ('"+sr.getScriptid()+"'," +
				"'"+sr.getScript()+"','"+sr.getNumber()+"','"+sr.getRole1()+"','"+sr.getRole2()+"'," +
						"'"+sr.getRole3()+"','"+sr.getRole3()+"')";
		DataConnect.getStat().executeUpdate(sql);
	}	

	public void exit() {

	}

}

