package model;

import java.sql.ResultSet;
import java.sql.SQLException;

public class jb {
	private int jbid;
	private String XianSuo;
	private String Juben;

	public jb(int jbid, String xianSuo, String juben) {
		super();
		this.jbid = jbid;
		XianSuo = xianSuo;
		Juben = juben;
	}

	public int getJbid() {
		return jbid;
	}

	public void setJbid(int jbid) {
		this.jbid = jbid;
	}

	public String getXianSuo() {
		return XianSuo;
	}

	public void setXianSuo(String xianSuo) {
		XianSuo = xianSuo;
	}

	public String getJuben() {
		return Juben;
	}

	public void setJuben(String juben) {
		Juben = juben;
	}

	public jb viewjb(int jbid) throws SQLException, ClassNotFoundException {
		jb jb1 = null;
		String sql = "select * from sb4 where jbid=" +jbid;
		ResultSet rs = DataConnect.getStat().executeQuery(sql);
		if (rs.next()) {
			jb1 = new jb(rs.getInt(1), rs.getString(2), rs.getString(3));
		}
		return jb1;
	}
}
