package serve;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import model.DataConnect;
import model.Role;
import model.Room;
import model.admin;
import model.user;
import model.visitscript;

public class JBServer implements JBProtocal {
	private Socket s;
	private ObjectInputStream ois;
	private ObjectOutputStream oos;

	public JBServer() throws IOException, SQLException, ClassNotFoundException {
		ServerSocket ss = new ServerSocket(1018);
		while (true) {
			s = ss.accept();
			ois = new ObjectInputStream(s.getInputStream());
			oos = new ObjectOutputStream(s.getOutputStream());
			int command = ois.readInt();
			if (command == U_ALOGING) {
				this.u_aloging();
			}
			if (command == U_REGISTER) {
				this.u_register();
			}
			if (command == U_CHOOSEROLE) {
				this.u_chooserole();
			}
			if (command == U_CREATROOM) {
				this.u_creatroom();
			}
			if (command == U_VISITSCRIPT) {
				this.a_visitscript();
			}
			if (command == A_ALOGING) {
				this.a_aloging();
			}
			if (command == A_VISITSCRIPT) {
				this.a_visitscript();
			}
			if (command == A_ADELETSCRIPT) {
				this.a_adeletscript();
			}
//			if (command == A_ADDSCRIPT) {
//				this.a_addscript();
//			}
			if (command == A_SEARCHUSER) {
				this.a_searchuser();
			}
			if (command == A_ADELETUSER) {
				this.a_adeletuser();
			}
		}
	}

	// �û�
	private void u_aloging() throws SQLException, ClassNotFoundException,
			IOException {
		// TODO Auto-generated method stub
		String uid = ois.readUTF();
		String password = ois.readUTF();
		user a = null;
		String sql = "select * from login where uid='" + uid
				+ "' and password = '" + password + "'";
		ResultSet rs = DataConnect.getStat().executeQuery(sql);
		if (rs.next()) {
			a = new user(uid, rs.getString("username"), password);
		}
		oos.writeObject(a);
		oos.flush();
	}

	public void u_register() throws SQLException, ClassNotFoundException,
			IOException {

		String uid = ois.readUTF();
		String upw = ois.readUTF();
		user u = null;
		String sql = "insert into login (uid,upw) values ('" + u.getUid()
				+ "','" + u.getUpw() + "')";
		DataConnect.getStat().executeUpdate(sql);

		oos.writeObject(u);
		oos.flush();
	}

	public String u_chooserole() {
		return null;
	}

	public void u_creatroom() throws SQLException, ClassNotFoundException,
			IOException {

		Room sr = (Room) ois.readObject();
		user u = (user) ois.readObject();
		String sql = "insert into room (scriptid,scriptname,number,role1,role2,role3,role4) values ('"
				+ sr.getScriptid()
				+ "',"
				+ "'"
				+ sr.getScript()
				+ "','"
				+ sr.getNumber()
				+ "','"
				+ sr.getRole1()
				+ "','"
				+ sr.getRole2()
				+ "',"
				+ "'"
				+ sr.getRole3()
				+ "','"
				+ sr.getRole4() + "')";
		DataConnect.getStat().executeUpdate(sql);

		oos.writeObject(sr);
		oos.flush();

	}

////	ѡ���ɫ
//	public void chooserole(Role r) throws SQLException, ClassNotFoundException {
//		
//		
//		String sql ="insert into record (role,story) values ('"+
//		r.getRolename()+"','"+r.getRquqing()+"')";
//		DataConnect.getStat().executeUpdate(sql);
//	}
	
	// �û��鿴�籾
	public ArrayList<visitscript> searchSC(String info) throws SQLException,
			ClassNotFoundException, IOException {

		user u = (user) ois.readObject();
		String info1 = ois.readUTF();

		ArrayList<visitscript> scs = new ArrayList<visitscript>();
		String sql = "select * from gg where gtitle like '%" + info1 + "%'";
		ResultSet rs = DataConnect.getStat().executeQuery(sql);
		while (rs.next()) {
			scs.add(new visitscript(rs.getInt("gid"), 0, 0, rs.getString(2), rs
					.getString(3), rs.getString(4), rs.getString(5), rs
					.getString(6), sql, sql, sql, sql, sql));
		}

		oos.writeObject(scs);
		oos.flush();
		return scs;
	}

	// ����Ա
	private void a_aloging() throws SQLException, ClassNotFoundException,
			IOException {

		String id = ois.readUTF();
		String pw = ois.readUTF();

		admin a = null;
		String sql = "select * from admin_login where id='" + id
				+ "' and password = '" + pw + "'";
		ResultSet rs = DataConnect.getStat().executeQuery(sql);
		if (rs.next()) {
			a = new admin(id, pw);
		}
		oos.writeObject(a);
		oos.flush();
		// TODO Auto-generated method stub
	}

	// �鿴�籾
	public void a_visitscript() throws SQLException, ClassNotFoundException,
			IOException {

		admin a = (admin) ois.readObject();
		String info = ois.readUTF();

		ArrayList<visitscript> scs = new ArrayList<visitscript>();
		String sql = "select * from gg where gtitle like '%" + info + "%'";
		ResultSet rs = DataConnect.getStat().executeQuery(sql);
		while (rs.next()) {
			scs.add(new visitscript(rs.getInt("gid"), 0, 0, rs.getString(2), rs
					.getString(3), rs.getString(4), rs.getString(5), rs
					.getString(6), sql, sql, sql, sql, sql));
		}

		oos.writeObject(scs);
		oos.flush();

	}

	// �����û�
	public ArrayList<user> a_searchuser() throws SQLException,
			ClassNotFoundException, IOException {

		admin a = (admin) ois.readObject();
		String username = ois.readUTF();

		ArrayList<user> users = new ArrayList<user>();
		String sql = "select * from login where username like '%" + username
				+ "%'";
		ResultSet rs = DataConnect.getStat().executeQuery(sql);
		while (rs.next()) {
			users.add(new user(rs.getString("uid"), rs.getString(2), rs
					.getString(3)));
		}

		oos.writeObject(a);
		oos.flush();
		return users;

	}

	// ���Ӿ籾
//	public void addscript(visitscript ss) throws SQLException,
//			ClassNotFoundException, IOException {
//		
//		admin a = (admin) ois.readObject();
//	    String scriptname = ois.readUTF();
//	    String number = ois.readUTF();
//	    String degree ois.readUTF();
//	    
//		String sql = "insert into viewscript (scriptname,number,degree) values ('"
//				+ ss.getScriptname()
//				+ "','"
//				+ ss.getNumber()
//				+ "','"
//				+ ss.getDegree() + "')";
//		DataConnect.getStat().executeUpdate(sql);
//	}

	// ɾ���籾
	public void a_adeletscript() throws SQLException, ClassNotFoundException,
			IOException {

		admin a = (admin) ois.readObject();
		String scriptname = ois.readUTF();

		String sql = "delete from script1 where scriptname =" + scriptname;
		DataConnect.getStat().executeUpdate(sql);

		oos.writeObject(a);
		oos.flush();

	}

	// ɾ���û�
	public void a_adeletuser() throws SQLException, ClassNotFoundException,
			IOException {

		admin a = (admin) ois.readObject();
		String username = ois.readUTF();

		String sql = "delete from login where username =" + username;
		DataConnect.getStat().executeUpdate(sql);

		oos.writeObject(a);
		oos.flush();

	}

	public static void main(String[] args) {
		try {
			new JBServer();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void run() {
		try {
			while (true) {
				ServerSocket ss = null;
				s = ss.accept();
				ois = new ObjectInputStream(s.getInputStream());
				oos = new ObjectOutputStream(s.getOutputStream());
				int command = ois.readInt();
				if (command == U_ALOGING) {
					this.u_aloging();
				}
				if (command == U_REGISTER) {
					this.u_register();
				}
				if (command == U_CHOOSEROLE) {
					this.u_chooserole();
				}
				if (command == U_CREATROOM) {
					this.u_creatroom();
				}
				if (command == U_VISITSCRIPT) {
					this.a_visitscript();
				}
				if (command == A_ALOGING) {
					this.a_aloging();
				}
				if (command == A_VISITSCRIPT) {
					this.a_visitscript();
				}
				if (command == A_ADELETSCRIPT) {
					this.a_adeletscript();
				}
//				if (command == A_ADDSCRIPT) {
//					this.a_addscript();
//				}
				if (command == A_SEARCHUSER) {
					this.a_searchuser();
				}
				if (command == A_ADELETUSER) {
					this.a_adeletuser();
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}