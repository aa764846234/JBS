package serve;

public interface JBProtocal {
	
	int U_ALOGING=1001;
	int U_REGISTER=1002;
	int U_CHOOSEROLE=1003;
	int U_CREATROOM=1004;
	int U_VISITSCRIPT=1005;
	
	int A_ALOGING=2001;
	int A_VISITSCRIPT=2002;
	int A_ADELETSCRIPT=2003;
	int A_SEARCHUSER=2004;
	int A_ADDSCRIPT=2005;
	int A_ADELETUSER=2006;
	int A_AALTEUSER=2007;

}
