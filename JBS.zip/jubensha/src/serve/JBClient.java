package serve;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.sql.SQLException;
import java.util.ArrayList;

import model.DataConnect;
import model.Role;
import model.Room;
import model.admin;
import model.user;
import model.visitscript;

public class JBClient implements JBProtocal {
	private static Socket s;
	private static ObjectOutputStream oos;
	private static ObjectInputStream ois;

	private static void init() throws UnknownHostException, IOException {
		s = new Socket("10.51.191.10", 1018);
		oos = new ObjectOutputStream(s.getOutputStream());
		ois = new ObjectInputStream(s.getInputStream());
	}

	// �û�����
	// ��¼
	public static user aloging(String uid, String upw)
			throws UnknownHostException, IOException, ClassNotFoundException {

		init();
		oos.writeInt(U_ALOGING);
		oos.flush();
		oos.writeUTF(uid);
		oos.flush();
		oos.writeUTF(upw);
		oos.flush();
		user u = (user) ois.readObject();
		return u;
	}

	// ע��
	public static user register(int uid, String password)
			throws UnknownHostException, IOException, ClassNotFoundException {

		init();
		oos.writeInt(U_REGISTER);
		oos.flush();
		oos.writeInt(uid);
		oos.flush();
		oos.writeUTF(password);
		oos.flush();
		user u = (user) ois.readObject();
		return u;
	}

	// ��������
	public static void creatroom(Room sr) throws SQLException,
			ClassNotFoundException, IOException {
		// TODO Auto-generated method stub
		init();
		oos.writeInt(U_CREATROOM);
		oos.flush();
		oos.writeObject(sr);
		oos.flush();
	}

	@SuppressWarnings("unchecked")
	public ArrayList<visitscript> searchSC(String info) throws SQLException,
			ClassNotFoundException, IOException {
		init();
		oos.writeInt(U_VISITSCRIPT);
		oos.flush();
		oos.writeObject(info);
		oos.flush();
		ArrayList<visitscript> visitscript = (ArrayList<visitscript>) ois
				.readObject();
		return visitscript;
	}

////	ѡ���ɫ
//	public void chooserole(Role r) throws SQLException, ClassNotFoundException,
//			IOException {
//		init();
//		oos.writeInt(U_CHOOSEROLE);
//		oos.flush();
//		oos.writeObject(r);
//		oos.flush();
//		
//	}
	// ����Ա����
	// ��¼
	public static admin login(String id, String pw)
			throws ClassNotFoundException, IOException {

		if (s == null)
			init();
		oos.writeInt(A_ALOGING);
		oos.flush();
		oos.writeUTF(id);
		oos.flush();
		oos.writeUTF(pw);
		oos.flush();
		admin u = (admin) ois.readObject();
		return u;
	}

	// �鿴�籾
	@SuppressWarnings("unchecked")
	public ArrayList<visitscript> searchsc(String info)
			throws ClassNotFoundException, IOException {

		if (s == null)
			init();
		oos.writeInt(A_VISITSCRIPT);
		oos.flush();
		oos.writeUTF(info);
		oos.flush();
		ArrayList<visitscript> visitscript = (ArrayList<visitscript>) ois
				.readObject();
		return visitscript;
	}

	// ɾ���籾
	public void Adeletscript(String scriptname) throws ClassNotFoundException,
			IOException {

		if (s == null)
			init();
		oos.writeInt(A_ADELETSCRIPT);
		oos.flush();
		oos.writeUTF(scriptname);
		oos.flush();
	}

	// ���Ӿ籾
	public void addscript(visitscript ss) throws SQLException,
			ClassNotFoundException, IOException {
		
		if(s==null)
			init();
		oos.writeInt(A_ADDSCRIPT);
		oos.flush();
		oos.writeObject(ss);
		oos.flush();
	}

	// �鿴�û�
	@SuppressWarnings("unchecked")
	public ArrayList<user> searchUser(String username)
			throws ClassNotFoundException, IOException {
		if (s == null)
			init();
		oos.writeInt(A_SEARCHUSER);
		oos.flush();
		oos.writeUTF(username);
		oos.flush();
		ArrayList<user> searchUser = (ArrayList<user>) ois.readObject();
		return searchUser;
	}

	// ɾ���û�
	public static void Adeletuser(String username)
			throws ClassNotFoundException, IOException {
		if (s == null)
			init();
		oos.writeInt(A_ADELETUSER);
		oos.flush();
		oos.writeUTF(username);
		oos.flush();
	}

}