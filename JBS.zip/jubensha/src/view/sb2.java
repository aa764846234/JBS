/*
 * sb2.java
 *
 * Created on __DATE__, __TIME__
 */

package view;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import serve.JBClient;

import model.DataConnect;
import model.Room;
import model.user;
import model.visitscript;

/**
 *
 * @author  __USER__
 */
public class sb2 extends javax.swing.JFrame {
	private user u;

	/** Creates new form sb2 */
	public sb2(Room r, user u, visitscript v,int scid) {
		this.u = u;
		initComponents(r,v,scid);
		this.jTextArea1.setText(v.getIntroduce());
		this.setLocationRelativeTo(null);
	}

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents(final Room r,final visitscript v,final int scid) {

		jLayeredPane1 = new javax.swing.JLayeredPane();
		jScrollPane1 = new javax.swing.JScrollPane();
		jTextArea1 = new javax.swing.JTextArea();
		jLabel1 = new javax.swing.JLabel();
		jButton1 = new javax.swing.JButton();
		jButton2 = new javax.swing.JButton();
		jLabel3 = new javax.swing.JLabel();
		jScrollPane2 = new javax.swing.JScrollPane();
		jTextArea2 = new javax.swing.JTextArea();
		jLabel2 = new javax.swing.JLabel();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jTextArea1.setColumns(20);
		jTextArea1.setRows(5);
		jTextArea1.setLineWrap(true);
		jScrollPane1.setViewportView(jTextArea1);

		jScrollPane1.setBounds(90, 130, 620, 330);
		jLayeredPane1.add(jScrollPane1, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jLabel1.setFont(new java.awt.Font("����", 3, 24));
		jLabel1.setForeground(new java.awt.Color(204, 204, 204));
		jLabel1.setText("\u5267\u672c\u7b80\u4ecb");
		jLabel1.setBounds(90, 60, -1, 60);
		jLayeredPane1.add(jLabel1, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jButton1.setBackground(new java.awt.Color(0, 0, 0));
		jButton1.setForeground(new java.awt.Color(255, 255, 255));
		jButton1.setText("\u8fd4\u56de");
		jButton1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton1ActionPerformed(evt);
			}
		});
		jButton1.setBounds(20, 20, 70, -1);
		jLayeredPane1.add(jButton1, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jButton2.setBackground(new java.awt.Color(0, 0, 0));
		jButton2.setForeground(new java.awt.Color(255, 255, 255));
		jButton2.setText("\u521b\u5efa\u623f\u95f4");
		jButton2.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				try {
					jButton2ActionPerformed(evt,r,v,scid);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		jButton2.setBounds(410, 490, 160, 70);
		jLayeredPane1.add(jButton2, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jLabel3.setBackground(new java.awt.Color(204, 204, 204));
		jLabel3.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 24));
		jLabel3.setForeground(new java.awt.Color(204, 204, 204));
		jLabel3.setText("\u5df2\u8fdb\u5165\u73a9\u5bb6\u59d3\u540d\uff1a");
		jLabel3.setBounds(740, 90, 210, 20);
		jLayeredPane1.add(jLabel3, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jTextArea2.setColumns(20);
		jTextArea2.setRows(5);
		jScrollPane2.setViewportView(jTextArea2);

		jScrollPane2.setBounds(740, 130, 190, 330);
		jLayeredPane1.add(jScrollPane2, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/3.jpg"))); // NOI18N
		jLabel2.setBounds(2, 0, 1010, 590);
		jLayeredPane1.add(jLabel2, javax.swing.JLayeredPane.DEFAULT_LAYER);

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jLayeredPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1016,
				Short.MAX_VALUE));
		layout.setVerticalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jLayeredPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 591,
				Short.MAX_VALUE));

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
		new sb1(u).setVisible(true);
		this.dispose();
	}

	private void jButton2ActionPerformed(java.awt.event.ActionEvent evt, Room ro, visitscript v,int scid) throws SQLException, ClassNotFoundException, IOException {
		Room r = null;
		try {
//			JBClient.creatroom(new Room(0,ro.getScriptid(),ro.getScript(),ro.getNumber(),v.getRole1(),v.getRole2(),v.getRole3(),v.getRole4()));
//			JBClient.creatroom(ro);
			user.creatroom(new Room(0,ro.getScriptid(),ro.getScript(),ro.getNumber(),v.getRole1(),v.getRole2(),v.getRole3(),v.getRole4()));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String sql1 = "select * from room where roomid=(select max(roomid) from room)";
		ResultSet rs = DataConnect.getStat().executeQuery(sql1);
		if (rs.next()) {
			r = new Room(rs.getInt(1), ro.getScriptid(), ro.getScript(),ro.getNumber(),ro.getRole1(),ro.getRole2(),
					ro.getRole3(),ro.getRole4());
		}
		new sb3(u,v,r,scid).setVisible(true);
		this.dispose();
	}				

	/**
	 * @param args the command line arguments
	 */

	//GEN-BEGIN:variables
	// Variables declaration - do not modify
	private javax.swing.JButton jButton1;
	private javax.swing.JButton jButton2;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JLayeredPane jLayeredPane1;
	private javax.swing.JScrollPane jScrollPane1;
	private javax.swing.JScrollPane jScrollPane2;
	private javax.swing.JTextArea jTextArea1;
	private javax.swing.JTextArea jTextArea2;
	// End of variables declaration//GEN-END:variables

}