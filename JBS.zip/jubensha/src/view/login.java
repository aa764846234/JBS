package view;

import java.io.IOException;
import java.net.UnknownHostException;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import serve.JBClient;
import serve.JBServer;


import model.user;

/*
 * login.java
 *
 * Created on __DATE__, __TIME__
 */

/**
 * 
 * @author __USER__
 */
public class login extends javax.swing.JFrame {

	/** Creates new form login */
	public login() {
		initComponents();
		this.setLocationRelativeTo(null);
	}

	// GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		jLayeredPane1 = new javax.swing.JLayeredPane();
		jTextField1 = new javax.swing.JTextField();
		jLabel2 = new javax.swing.JLabel();
		jLabel3 = new javax.swing.JLabel();
		jButton1 = new javax.swing.JButton();
		jButton2 = new javax.swing.JButton();
		jPasswordField1 = new javax.swing.JPasswordField();
		jLabel4 = new javax.swing.JLabel();
		jLabel1 = new javax.swing.JLabel();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		setTitle("\u767b\u5f55\u754c\u9762");

		jTextField1.setBackground(new java.awt.Color(153, 153, 153));
		jTextField1.setBounds(440, 330, 190, 20);
		jLayeredPane1.add(jTextField1, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jLabel2.setBackground(new java.awt.Color(153, 153, 153));
		jLabel2.setForeground(new java.awt.Color(204, 204, 204));
		jLabel2.setText("\u7528\u6237\u540d\uff1a");
		jLabel2.setBounds(380, 330, 70, 20);
		jLayeredPane1.add(jLabel2, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jLabel3.setBackground(new java.awt.Color(153, 153, 153));
		jLabel3.setForeground(new java.awt.Color(204, 204, 204));
		jLabel3.setText("\u5bc6\u7801\uff1a");
		jLabel3.setBounds(390, 360, 50, 20);
		jLayeredPane1.add(jLabel3, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jButton1.setBackground(new java.awt.Color(0, 0, 0));
		jButton1.setForeground(new java.awt.Color(153, 153, 153));
		jButton1.setText("\u767b\u5f55");
		jButton1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				try {
					jButton1ActionPerformed(evt);
				} catch (UnknownHostException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		jButton1.setBounds(550, 410, 70, 29);
		jLayeredPane1.add(jButton1, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jButton2.setBackground(new java.awt.Color(0, 0, 0));
		jButton2.setForeground(new java.awt.Color(153, 153, 153));
		jButton2.setText("\u6ce8\u518c");
		jButton2.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton2ActionPerformed(evt);
			}
		});
		jButton2.setBounds(450, 410, 63, 29);
		jLayeredPane1.add(jButton2, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jPasswordField1.setBackground(new java.awt.Color(153, 153, 153));
		jPasswordField1.setBounds(440, 360, 190, 20);
		jLayeredPane1.add(jPasswordField1,
				javax.swing.JLayeredPane.DEFAULT_LAYER);

		jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�籾ɱ2.png"))); // NOI18N
		jLabel4.setBounds(20, 20, 1036, 200);
		jLayeredPane1.add(jLabel4, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/2.jpg"))); // NOI18N
		jLabel1.setText("jLabel1");
		jLabel1.setBounds(-10, 0, 930, 590);
		jLayeredPane1.add(jLabel1, javax.swing.JLayeredPane.DEFAULT_LAYER);

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jLayeredPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 922,
				Short.MAX_VALUE));
		layout.setVerticalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jLayeredPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 590,
				Short.MAX_VALUE));

		pack();
	}// </editor-fold>

	// GEN-END:initComponents

	private void jButton1ActionPerformed(java.awt.event.ActionEvent evt)
			throws UnknownHostException, IOException, SQLException {
		String id = this.jTextField1.getText();
		String upw = this.jPasswordField1.getText();
		try {
			int uid = Integer.parseInt(id);
			user u = JBClient.aloging(id, upw);
			if (u == null)
				JOptionPane.showMessageDialog(this, "��½ʧ��");
			else {
				new MainView(u).setVisible(true);
				this.dispose();
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(this, "�����쳣");
		}
	}

	private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
		new register().setVisible(true);
		this.dispose();
	}

	/**
	 * @param args
	 *            the command line arguments
	 */
	public static void main(String args[]) {
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new login().setVisible(true);
			}
		});
	}

	// GEN-BEGIN:variables
	// Variables declaration - do not modify
	private javax.swing.JButton jButton1;
	private javax.swing.JButton jButton2;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JLabel jLabel4;
	private javax.swing.JLayeredPane jLayeredPane1;
	private javax.swing.JPasswordField jPasswordField1;
	private javax.swing.JTextField jTextField1;
	// End of variables declaration//GEN-END:variables

}