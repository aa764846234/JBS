/*
 * simple5.java
 *
 * Created on __DATE__, __TIME__
 */

package view;

import model.user;

/**
 *
 * @author  __USER__
 */
public class simple5 extends javax.swing.JFrame {
	
	private user u;

	/** Creates new form simple5 */
	public simple5() {
		initComponents();
		this.setLocationRelativeTo(null);
	}

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		jLayeredPane1 = new javax.swing.JLayeredPane();
		jButton13 = new javax.swing.JButton();
		jButton14 = new javax.swing.JButton();
		jButton5 = new javax.swing.JButton();
		jLabel2 = new javax.swing.JLabel();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jButton13.setBackground(new java.awt.Color(0, 0, 0));
		jButton13.setForeground(new java.awt.Color(255, 255, 255));
		jButton13.setText("\u4e0b\u4e00\u9636\u6bb5");
		jButton13.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton13ActionPerformed(evt);
			}
		});
		jButton13.setBounds(900, 541, -1, -1);
		jLayeredPane1.add(jButton13, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jButton14.setBackground(new java.awt.Color(0, 0, 0));
		jButton14.setForeground(new java.awt.Color(255, 255, 255));
		jButton14.setText("\u9000\u51fa\u623f\u95f4");
		jButton14.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton14ActionPerformed(evt);
			}
		});
		jButton14.setBounds(790, 540, -1, 30);
		jLayeredPane1.add(jButton14, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�籾-1.PNG"))); // NOI18N
		jButton5.setText("jButton1");
		jButton5.setBounds(60, 100, 260, 150);
		jLayeredPane1.add(jButton5, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/3.jpg"))); // NOI18N
		jLabel2.setBounds(0, 0, 1020, 600);
		jLayeredPane1.add(jLabel2, javax.swing.JLayeredPane.DEFAULT_LAYER);

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jLayeredPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1026,
				javax.swing.GroupLayout.PREFERRED_SIZE));
		layout.setVerticalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jLayeredPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 598,
				javax.swing.GroupLayout.PREFERRED_SIZE));

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {
		new MainView(u).setVisible(true);
		this.dispose();
	}

	private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {
		new sb2(null,u,null,0).setVisible(true);
		this.dispose();
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new simple5().setVisible(true);
			}
		});
	}

	//GEN-BEGIN:variables
	// Variables declaration - do not modify
	private javax.swing.JButton jButton13;
	private javax.swing.JButton jButton14;
	private javax.swing.JButton jButton5;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLayeredPane jLayeredPane1;
	// End of variables declaration//GEN-END:variables

}