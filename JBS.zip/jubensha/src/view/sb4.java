/*
 * sb4.java
 *
 * Created on __DATE__, __TIME__
 */

package view;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JFormattedTextField;
import javax.swing.JOptionPane;
import javax.swing.text.Caret;
import model.DataConnect;
import model.Role;
import model.Room;
import model.jb;
import model.user;
import model.visitscript;

/**
 *
 * @author  __USER__
 */
public class sb4 extends javax.swing.JFrame implements Runnable {

	private user u;
	Role rl = null;

	/** Creates new form sb4 
	 * @throws ClassNotFoundException 
	 * @throws SQLException */
	public sb4(user u, Room r, visitscript v) throws SQLException,
			ClassNotFoundException {
		Thread t = new Thread(this);
		t.start();
		this.u = u;
		String sql1 = "select * from record where username =" + u.getUid();
		ResultSet rs = DataConnect.getStat().executeQuery(sql1);
		if (rs.next()) {
			rl = new Role(rs.getString(1), rs.getInt(2), rs.getString(3), rs
					.getString(4));
		}
		initComponents(r, rl, v);
		this.jTextArea1.setText(rl.getRquqing());
		this.setLocationRelativeTo(null);
	}



	public void loadInfo() throws SQLException, ClassNotFoundException {
		this.jTextArea2.setText("");
		String info = "";
		String sql = "select * from chat";
		String c;
		ResultSet rs = DataConnect.getStat().executeQuery(sql);
		while (rs.next()) {
			c = rs.getString(1) + ":" + rs.getString(2) + "\n";
			info += c;
		}
		this.jTextArea2.setText(info);
	}

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents(final Room r,final Role rl,final visitscript v) {

		jLayeredPane1 = new javax.swing.JLayeredPane();
		button2 = new java.awt.Button();
		label2 = new java.awt.Label();
		jLabel2 = new javax.swing.JLabel();
		jLabel3 = new javax.swing.JLabel();
		jScrollPane2 = new javax.swing.JScrollPane();
		jTextArea2 = new javax.swing.JTextArea();
		jTextField2 = new javax.swing.JTextField();
		jButton1 = new javax.swing.JButton();
		jScrollPane1 = new javax.swing.JScrollPane();
		jTextArea1 = new javax.swing.JTextArea();
		jLabel1 = new javax.swing.JLabel();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		button2.setBackground(new java.awt.Color(0, 0, 0));
		button2.setFont(new java.awt.Font("΢���ź�", 0, 14));
		button2.setForeground(new java.awt.Color(255, 255, 255));
		button2.setLabel("\u4e0b\u4e00\u9636\u6bb5");
		button2.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				try {
					button2ActionPerformed(evt,r,rl,v);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		button2.setBounds(870, 510, 72, 27);
		jLayeredPane1.add(button2, javax.swing.JLayeredPane.DEFAULT_LAYER);

		label2.setBackground(new java.awt.Color(0, 0, 0));
		label2.setFont(new java.awt.Font("΢���ź�", 0, 24));
		label2.setForeground(new java.awt.Color(255, 255, 255));
		label2.setText("\u4e00\u8f6e\u5267\u60c5");
		label2.setBounds(30, 20, 100, 37);
		jLayeredPane1.add(label2, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jLabel2.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 24));
		jLabel2.setForeground(new java.awt.Color(255, 255, 255));
		jLabel2.setText("\u804a\u5929\u6846");
		jLabel2.setBounds(630, 10, 90, 32);
		jLayeredPane1.add(jLabel2, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jLabel3.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jLabel3.setForeground(new java.awt.Color(255, 255, 255));
		jLabel3.setText("\u8bf7\u8f93\u5165\u6587\u5b57\uff1a");
		jLabel3.setBounds(630, 280, 110, 24);
		jLayeredPane1.add(jLabel3, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jTextArea2.setColumns(20);
		jTextArea2.setRows(5);
		jScrollPane2.setViewportView(jTextArea2);

		jScrollPane2.setBounds(630, 60, 310, 220);
		jLayeredPane1.add(jScrollPane2, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jTextField2.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jTextField2ActionPerformed(evt);
			}
		});
		jTextField2.setBounds(630, 310, 310, 30);
		jLayeredPane1.add(jTextField2, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jButton1.setBackground(new java.awt.Color(0, 0, 0));
		jButton1.setForeground(new java.awt.Color(255, 255, 255));
		jButton1.setText("\u53d1\u9001");
		jButton1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton1ActionPerformed(evt,rl);
			}
		});
		jButton1.setBounds(870, 350, 70, 30);
		jLayeredPane1.add(jButton1, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jTextArea1.setColumns(20);
		jTextArea1.setRows(5);
		jScrollPane1.setViewportView(jTextArea1);

		jScrollPane1.setBounds(30, 60, 590, 450);
		jLayeredPane1.add(jScrollPane1, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/3.jpg"))); // NOI18N
		jLabel1.setBounds(0, 0, 970, 560);
		jLayeredPane1.add(jLabel1, javax.swing.JLayeredPane.DEFAULT_LAYER);

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jLayeredPane1, javax.swing.GroupLayout.Alignment.TRAILING,
				javax.swing.GroupLayout.DEFAULT_SIZE, 967, Short.MAX_VALUE));
		layout.setVerticalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jLayeredPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 558,
				Short.MAX_VALUE));

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {
	}

	private void jButton1ActionPerformed(java.awt.event.ActionEvent evt,Role rl) {
		String sql = "insert into chat(username,context) values('"
				+ rl.getRolename() + "','" + this.jTextField2.getText() + "')";
		try {
			DataConnect.getStat().executeUpdate(sql);
			loadInfo();
			this.jTextField2.setText("");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void button2ActionPerformed(java.awt.event.ActionEvent evt,
			Room r, Role rl, visitscript v) throws SQLException,
			ClassNotFoundException {
		new sb5(u, rl, v).setVisible(true);
		this.dispose();
	}

	/**
	 * @param args the command line arguments
	 */

	//GEN-BEGIN:variables
	// Variables declaration - do not modify
	private java.awt.Button button2;
	private javax.swing.JButton jButton1;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JLayeredPane jLayeredPane1;
	private javax.swing.JScrollPane jScrollPane1;
	private javax.swing.JScrollPane jScrollPane2;
	private javax.swing.JTextArea jTextArea1;
	private javax.swing.JTextArea jTextArea2;
	private javax.swing.JTextField jTextField2;
	private java.awt.Label label2;
	// End of variables declaration//GEN-END:variables

	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(true){
			
				try {
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					loadInfo();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			
		}
	}

}