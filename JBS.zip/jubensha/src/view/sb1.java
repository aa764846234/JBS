/*
 * sb1.java
 *
 * Created on __DATE__, __TIME__
 */

package view;

import java.sql.ResultSet;
import java.sql.SQLException;

import model.DataConnect;
import model.Room;
import model.user;
import model.visitscript;

/**
 *
 * @author  __USER__
 */
public class sb1 extends javax.swing.JFrame {

	private user u;

	/** Creates new form sb1 */
	public sb1(user u) {
		this.u = u;
		initComponents();
		this.setLocationRelativeTo(null);
	}

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		jLayeredPane1 = new javax.swing.JLayeredPane();
		jButton4 = new javax.swing.JButton();
		jLabel1 = new javax.swing.JLabel();
		jButton5 = new javax.swing.JButton();
		jButton6 = new javax.swing.JButton();
		jButton1 = new javax.swing.JButton();
		jButton2 = new javax.swing.JButton();
		jButton3 = new javax.swing.JButton();
		jButton14 = new javax.swing.JButton();
		jLabel3 = new javax.swing.JLabel();
		jLabel4 = new javax.swing.JLabel();
		jLabel5 = new javax.swing.JLabel();
		jLabel6 = new javax.swing.JLabel();
		jLabel7 = new javax.swing.JLabel();
		jLabel2 = new javax.swing.JLabel();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/sb2(1).jpg"))); // NOI18N
		jButton4.setText("jButton1");
		jButton4.setBounds(400, 130, 190, 130);
		jLayeredPane1.add(jButton4, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jLabel1.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jLabel1.setForeground(new java.awt.Color(255, 255, 255));
		jLabel1.setText("\u548c\u5e73\u996d\u5e97");
		jLabel1.setBounds(460, 270, 80, 30);
		jLayeredPane1.add(jLabel1, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/sb4(1).jpg"))); // NOI18N
		jButton5.setText("jButton1");
		jButton5.setBounds(80, 330, 200, 110);
		jLayeredPane1.add(jButton5, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/sb5(1).jpg"))); // NOI18N
		jButton6.setText("jButton1");
		jButton6.setBounds(400, 340, 190, 110);
		jLayeredPane1.add(jButton6, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/sb1(1).jpg"))); // NOI18N
		jButton1.setText("\u5267\u672c1");
		jButton1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				try {
					jButton1ActionPerformed(evt);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		jButton1.setBounds(80, 130, 200, 120);
		jLayeredPane1.add(jButton1, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/sb6(1).jpg"))); // NOI18N
		jButton2.setText("jButton1");
		jButton2.setBounds(720, 350, 190, 110);
		jLayeredPane1.add(jButton2, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/sb3(1).jpg"))); // NOI18N
		jButton3.setText("jButton1");
		jButton3.setBounds(720, 140, 190, 120);
		jLayeredPane1.add(jButton3, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jButton14.setBackground(new java.awt.Color(0, 0, 0));
		jButton14.setForeground(new java.awt.Color(255, 255, 255));
		jButton14.setText("\u9000\u51fa\u623f\u95f4");
		jButton14.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton14ActionPerformed(evt);
			}
		});
		jButton14.setBounds(790, 550, 81, 25);
		jLayeredPane1.add(jButton14, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jLabel3.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jLabel3.setForeground(new java.awt.Color(255, 255, 255));
		jLabel3.setText("\u7981\u6b62\u5165\u5185");
		jLabel3.setBounds(780, 270, 80, 30);
		jLayeredPane1.add(jLabel3, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jLabel4.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jLabel4.setForeground(new java.awt.Color(255, 255, 255));
		jLabel4.setText("\u7f6a\u6076");
		jLabel4.setBounds(470, 450, 36, 30);
		jLayeredPane1.add(jLabel4, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jLabel5.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jLabel5.setForeground(new java.awt.Color(255, 255, 255));
		jLabel5.setText("\u65e0\u95f4\u65c5\u9014");
		jLabel5.setBounds(140, 260, 80, 30);
		jLayeredPane1.add(jLabel5, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jLabel6.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jLabel6.setForeground(new java.awt.Color(255, 255, 255));
		jLabel6.setText("\u970d\u7279\u987f\u5e84\u56ed");
		jLabel6.setBounds(770, 460, 90, 30);
		jLayeredPane1.add(jLabel6, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jLabel7.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jLabel7.setForeground(new java.awt.Color(255, 255, 255));
		jLabel7.setText("\u6700\u540e\u7684\u6551\u8d4e");
		jLabel7.setBounds(130, 450, 90, 30);
		jLayeredPane1.add(jLabel7, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/3.jpg"))); // NOI18N
		jLabel2.setBounds(6, -2, 1020, 610);
		jLayeredPane1.add(jLabel2, javax.swing.JLayeredPane.DEFAULT_LAYER);

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jLayeredPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1021,
				Short.MAX_VALUE));
		layout.setVerticalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				layout.createSequentialGroup().addComponent(jLayeredPane1,
						javax.swing.GroupLayout.PREFERRED_SIZE, 610,
						javax.swing.GroupLayout.PREFERRED_SIZE)
						.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE,
								Short.MAX_VALUE)));

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	private Room jButton1ActionPerformed(java.awt.event.ActionEvent evt)
			throws SQLException, ClassNotFoundException {
		Room r = null;
		visitscript v = null;
		int scid = 11;
		String sql1 = "select * from viewscript where scriptid =" + scid;
		ResultSet rs1 = DataConnect.getStat().executeQuery(sql1);
		if (rs1.next()) {
			r = new Room(0, rs1.getInt(1), rs1.getString(2), rs1.getInt(3),
					" ", " ", " ", " ");
		}
		String sql2 = "select * from juqing where scriptid =" + scid;
		ResultSet rs2 = DataConnect.getStat().executeQuery(sql2);
		if (rs2.next()) {
			v = new visitscript(rs2.getInt(1), rs2.getInt(2), rs2.getInt(3),
					rs2.getString(4), rs2.getString(5), rs2.getString(6), rs2
							.getString(7), rs2.getString(8), rs2.getString(9),
					rs2.getString(10), rs2.getString(11), rs2.getString(12),
					rs2.getString(13));
		}
		new sb2(r, u, v, scid).setVisible(true);
		this.dispose();
		return r;
	}

	private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {
		new MainView(u).setVisible(true);
		this.dispose();
	}

	private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	/**
	 * @param args the command line arguments
	 */

	//GEN-BEGIN:variables
	// Variables declaration - do not modify
	private javax.swing.JButton jButton1;
	private javax.swing.JButton jButton14;
	private javax.swing.JButton jButton2;
	private javax.swing.JButton jButton3;
	private javax.swing.JButton jButton4;
	private javax.swing.JButton jButton5;
	private javax.swing.JButton jButton6;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JLabel jLabel4;
	private javax.swing.JLabel jLabel5;
	private javax.swing.JLabel jLabel6;
	private javax.swing.JLabel jLabel7;
	private javax.swing.JLayeredPane jLayeredPane1;
	// End of variables declaration//GEN-END:variables

}