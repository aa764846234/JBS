/*
 * register.java
 *
 * Created on __DATE__, __TIME__
 */

package view;

import java.sql.SQLException;

import javax.swing.JOptionPane;

import model.DataConnect;
import model.user;

/**
 *
 * @author  __USER__
 */
public class register extends javax.swing.JFrame {

	/** Creates new form register */
	public register() {
		initComponents();
		this.setLocationRelativeTo(null);
	}

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		jLayeredPane1 = new javax.swing.JLayeredPane();
		jTextField1 = new javax.swing.JTextField();
		jPasswordField1 = new javax.swing.JPasswordField();
		jLabel2 = new javax.swing.JLabel();
		jLabel3 = new javax.swing.JLabel();
		jButton1 = new javax.swing.JButton();
		jLabel4 = new javax.swing.JLabel();
		jPasswordField2 = new javax.swing.JPasswordField();
		jLabel5 = new javax.swing.JLabel();
		jLabel1 = new javax.swing.JLabel();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jTextField1.setBackground(new java.awt.Color(153, 153, 153));
		jTextField1.setBounds(460, 340, 170, 23);
		jLayeredPane1.add(jTextField1, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jPasswordField1.setBackground(new java.awt.Color(153, 153, 153));
		jPasswordField1.setBounds(460, 380, 170, 21);
		jLayeredPane1.add(jPasswordField1,
				javax.swing.JLayeredPane.DEFAULT_LAYER);

		jLabel2.setBackground(new java.awt.Color(153, 153, 153));
		jLabel2.setForeground(new java.awt.Color(204, 204, 204));
		jLabel2.setText("\u7528\u6237\u540d\uff1a");
		jLabel2.setBounds(400, 340, 70, 17);
		jLayeredPane1.add(jLabel2, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jLabel3.setBackground(new java.awt.Color(153, 153, 153));
		jLabel3.setForeground(new java.awt.Color(204, 204, 204));
		jLabel3.setText("\u5bc6\u7801\uff1a");
		jLabel3.setBounds(410, 380, 36, 17);
		jLayeredPane1.add(jLabel3, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jButton1.setBackground(new java.awt.Color(0, 0, 0));
		jButton1.setForeground(new java.awt.Color(153, 153, 153));
		jButton1.setText("\u6ce8\u518c");
		jButton1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				try {
					jButton1ActionPerformed(evt);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		jButton1.setBounds(510, 460, 57, 25);
		jLayeredPane1.add(jButton1, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jLabel4.setForeground(new java.awt.Color(204, 204, 204));
		jLabel4.setText("\u786e\u8ba4\u5bc6\u7801\uff1a");
		jLabel4.setBounds(380, 420, 80, 17);
		jLayeredPane1.add(jLabel4, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jPasswordField2.setBackground(new java.awt.Color(153, 153, 153));
		jPasswordField2.setBounds(460, 420, 170, 21);
		jLayeredPane1.add(jPasswordField2,
				javax.swing.JLayeredPane.DEFAULT_LAYER);

		jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/�籾ɱ2.png"))); // NOI18N
		jLabel5.setBounds(20, 10, 980, 190);
		jLayeredPane1.add(jLabel5, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/2.jpg"))); // NOI18N
		jLabel1.setBounds(0, 0, 920, 580);
		jLayeredPane1.add(jLabel1, javax.swing.JLayeredPane.DEFAULT_LAYER);

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jLayeredPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 923,
				Short.MAX_VALUE));
		layout.setVerticalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jLayeredPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 580,
				Short.MAX_VALUE));

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) throws SQLException, ClassNotFoundException {
		try {
			user.register(new user(this.jTextField1.getText()," ",this.jPasswordField1
					.getText()));
			JOptionPane.showMessageDialog(this, "ע��ɹ�");
			new login().setVisible(true);
			this.dispose();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this, "ע��ʧ��");
			e.printStackTrace();
		}
	}

	/**
	 * @param args the command line arguments
	 */

	//GEN-BEGIN:variables
	// Variables declaration - do not modify
	private javax.swing.JButton jButton1;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JLabel jLabel4;
	private javax.swing.JLabel jLabel5;
	private javax.swing.JLayeredPane jLayeredPane1;
	private javax.swing.JPasswordField jPasswordField1;
	private javax.swing.JPasswordField jPasswordField2;
	private javax.swing.JTextField jTextField1;
	// End of variables declaration//GEN-END:variables

}